function validateLogin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // Example validation (replace with your actual authentication logic)
    if (username === "example" && password === "password") {
        alert("Login successful!");
        window.location.href = "dashboard.html"; // Redirect to the dashboard page
    } else {
        alert("Invalid username or password. Please try again.");
    }
}
function validateLogin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // Example validation (replace with your actual authentication logic)
    var validCredentials = [
        { username: "example", password: "password" },
        { username: "afnas", password: "12345" }
    ];

    // Check if the entered credentials match any valid credentials
    var isValid = validCredentials.some(function(cred) {
        return cred.username === username && cred.password === password;
    });

    if (isValid) {
        alert("Login successful!");
        window.location.href = "dashboard.html"; // Redirect to the dashboard page
    } else {
        alert("Invalid username or password. Please try again.");
    }
}